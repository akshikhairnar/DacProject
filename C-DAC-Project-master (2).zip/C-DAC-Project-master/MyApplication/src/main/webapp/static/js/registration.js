function validateform(){ 

    var ck_name = /^[A-Za-z0-9 ]{3,20}$/;
    var ck_password =  /^[A-Za-z0-9!@#$%^&*()_]{6,20}$/;
    var ck_age = /^[0-9]{2}$/;


    var name =document.myform.username.value;
    var fname =document. myform.firstname.value;
    var lname =document. myform.lastname.value;
    var passd =document.myform.Password.value;
    var age =document.myform.age.value;

 var errors = [];
    
        if (!ck_name.test(name)||!name ) {
        errors[errors.length] = "Invalid Username.";
       }
       if (!ck_name.test(lname)||!lname ) {
        errors[errors.length] = " Invalid First name.";
        if (!ck_name.test(fname)||!fname ) {
            errors[errors.length] = " Invalid Last name.";
       }
     

        if (!ck_password.test(passd)||!passd ) {
            errors[errors.length] = "Invalid Password .";
           }
      
        if (!ck_age.test(age)||!age ) {
            errors[errors.length] = "Invalid age";
           }

    
           if (errors.length > 0) {
    
            reportErrors(errors);
            return false;
           }
            return true;
          }
          
          function reportErrors(errors){
           var msg = "Please Enter Valide Data...\n";
           for (var i = 0; i<errors.length; i++) {
           var numError = i + 1;
            msg += "\n" + numError + ". " + errors[i];
          }
           alert(msg);
    
    
    
    
    }
}