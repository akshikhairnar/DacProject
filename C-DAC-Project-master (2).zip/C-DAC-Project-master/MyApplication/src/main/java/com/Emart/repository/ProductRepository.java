package com.Emart.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.Emart.modal.Product;
import com.Emart.modal.User;

public interface ProductRepository extends CrudRepository<Product, Integer> {

	public List<Product> findAllById(Integer ids);
	
}