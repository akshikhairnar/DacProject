package com.Emart.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Emart.modal.Product;
import com.Emart.modal.UserCart;
import com.Emart.services.CartServices;
import com.Emart.services.ProductServiceImpl;

@Controller
public class CartController {
	
	@Autowired
	CartServices cartServices;
	
	@Autowired
	ProductServiceImpl productService;
	
	@GetMapping("/displayCart")
	public String trythis(HttpServletRequest request) {
		request.setAttribute("Items", cartServices.showAllItems());
//		request.setAttribute("mode", "ALL_USERS");
		return "cartDisplay";
	}
	
	@RequestMapping("/add-cart/{id}")
	public String editUser1(@PathVariable Integer id,HttpServletRequest request) {
		System.out.println("Inside"+ id);
		Product product = productService.getProductById(id);
		System.out.println(product.getName());
		UserCart userCart = new UserCart();
		userCart.setId(product.getId());
		userCart.setUserId(product.getProductId());
		userCart.setPrice(product.getPrice());
		cartServices.addToCart(userCart);

		return "redirect:/welcome";
	}
	
	@RequestMapping("/delete-cart-product/{id}")
	public String delete(@PathVariable Integer id) {
		cartServices.deleteCartProduct(id);
		return "redirect:/displayCart";
	}
	
}
