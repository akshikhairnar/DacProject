package com.Emart.repository;

import org.springframework.data.repository.CrudRepository;

import com.Emart.modal.Login;
import com.Emart.modal.User;

public interface LoginRepository extends CrudRepository<Login, Integer>{
	
	public Login findByuserNameAndPassword(String userName, String password);

}
