package com.Emart.repository;

import org.springframework.data.repository.CrudRepository;

import com.Emart.modal.UserCart;

public interface CartRepository extends CrudRepository<UserCart, Integer> {
	
	
}
