package com.Emart.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Emart.modal.Login;
import com.Emart.modal.User;
import com.Emart.services.LoginServices;
import com.Emart.services.UserService;

public class LoginController {
	@Autowired
	LoginServices loginServices;
	@Autowired
	UserService userService;

//	@PostMapping("/save-user")
//	public String registerUser(@ModelAttribute User user, BindingResult bindingResult, HttpServletRequest request) {
//		
//		System.out.println("in save-user");
//		
////		Login login = new Login();
////		
////		login.setPassword(user.getPassword());
////		login.setRoll("Customer");
////		login.setUserName(user.getUsername());
////		
////		loginServices.addLogin(login);
////		System.out.println("Inserted Successfully");
////		
////		userService.saveMyUser(user);
//
//		return "welcomepage";
//	}
//	
}
