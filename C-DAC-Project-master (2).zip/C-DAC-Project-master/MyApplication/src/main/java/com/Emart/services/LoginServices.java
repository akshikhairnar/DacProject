package com.Emart.services;



import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Emart.modal.Login;
import com.Emart.modal.User;
import com.Emart.repository.LoginRepository;

@Service
@Transactional
public class LoginServices {
	
	@Autowired
	LoginRepository loginrepository;
	
    public Login addLogin(Login login) {
        return loginrepository.save(login);
    }
    
    public Login findByuserNameAndPassword(String userName, String password) {
    	
    	return loginrepository.findByuserNameAndPassword(userName, password);
    	
    }
    

}
