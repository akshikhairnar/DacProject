
package com.Emart.controller;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.Emart.modal.Customer;
import com.Emart.modal.Login;
import com.Emart.modal.Product;
import com.Emart.modal.User;
import com.Emart.services.CustomerService;
import com.Emart.services.LoginServices;
import com.Emart.services.ProductService;
import com.Emart.services.ProductServiceImpl;
import com.Emart.services.UserService;

@Controller
public class ApplicationController {

	@Autowired
	UserService userService;
	@Autowired
	ProductServiceImpl productService;
	@Autowired
	LoginServices loginServices;
	@Autowired
	CustomerService customerService;
	
	


//	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
//	public String Welcome(HttpServletRequest request,Model model) {
//		model.addAttribute("products", productService.listAllProducts());
//		//request.setAttribute("mode", "MODE_HOME");
//		return "customerDashbord";
//	}

//	@RequestMapping("/register")
//	public String registration(HttpServletRequest request) {
//		request.setAttribute("mode", "MODE_REGISTER");
//		return "welcomepage";
//	}
	
	@RequestMapping("/registration")
	public String registration(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_REGISTER");
		return "registration";
	}
	
	@RequestMapping("/seller-registration")
	public String sellerregistration(HttpServletRequest request) {
		request.setAttribute("mode", "REGISTER_SELLER");
		return "registration";
	}

//	@PostMapping("/save-user")
//	public String registerUser(@ModelAttribute User user, BindingResult bindingResult, HttpServletRequest request) {
//		userService.saveMyUser(user);
//		request.setAttribute("mode", "MODE_HOME");
//		return "welcomepage";
//	}
	
	@PostMapping("/save-user")
	public String registerUser(@ModelAttribute User user, BindingResult bindingResult, HttpServletRequest request) {
		
		String generatedPassword=null;
		
		 try { 
			  
	            // Static getInstance method is called with hashing SHA 
	            MessageDigest md = MessageDigest.getInstance("SHA-256"); 
	  
	            // digest() method called 
	            // to calculate message digest of an input 
	            // and return array of byte 
	            byte[] messageDigest = md.digest(user.getPassword().getBytes()); 
	  
	            // Convert byte array into signum representation 
	            BigInteger no = new BigInteger(1, messageDigest); 
	  
	            // Convert message digest into hex value 
	            generatedPassword = no.toString(16); 
	  
	            while (generatedPassword.length() < 32) { 
	            	generatedPassword = "0" + generatedPassword; 
	            } 
	            
	            System.out.println(generatedPassword);
	  
	            
	        } 
	  
	        // For specifying wrong message digest algorithms 
	        catch (NoSuchAlgorithmException e) { 
	            System.out.println("Exception thrown"
	                               + " for incorrect algorithm: " + e); 
	  
	            return null; 
	        } 
	    
    
	
		
		System.out.println("in save-user");
		
		Login login = new Login();
		
		login.setPassword(generatedPassword);
		login.setRoll("Customer");
		login.setUserName(user.getUsername());
		
		loginServices.addLogin(login);
		System.out.println("Inserted Successfully");
		
		//userService.saveMyUser(user);
		
		Customer customer=new Customer();
		customer.setFirstName(user.getFirstname());
		customer.setLastName(user.getLastname());
		customer.setEmail(user.getEmail());
//		System.out.println("Showing address : "+user.getAddress());
//		customer.setAddress(user.getAddress());
//		System.out.println("Showing Mobile : "+user.getMobileNo());
//		customer.setMobileNo(user.getMobileNo());
		
		customerService.saveCustomer(customer);
		
		

		return "redirect:/login";
	}
	
	
	@PostMapping("/save-seller")
	public String registerSeller(@ModelAttribute User user, BindingResult bindingResult, HttpServletRequest request) {
		String generatedPassword=null;
		
		 try { 
			  
	            // Static getInstance method is called with hashing SHA 
	            MessageDigest md = MessageDigest.getInstance("SHA-256"); 
	  
	            // digest() method called 
	            // to calculate message digest of an input 
	            // and return array of byte 
	            byte[] messageDigest = md.digest(user.getPassword().getBytes()); 
	  
	            // Convert byte array into signum representation 
	            BigInteger no = new BigInteger(1, messageDigest); 
	  
	            // Convert message digest into hex value 
	            generatedPassword = no.toString(16); 
	  
	            while (generatedPassword.length() < 32) { 
	            	generatedPassword = "0" + generatedPassword; 
	            } 
	  
	            
	        } 
	  
	        // For specifying wrong message digest algorithms 
	        catch (NoSuchAlgorithmException e) { 
	            System.out.println("Exception thrown"
	                               + " for incorrect algorithm: " + e); 
	  
	            return null; 
	        } 
    
	
		
		System.out.println("in save-user");
		
		Login login = new Login();
		
		login.setPassword(generatedPassword);
		login.setRoll("Seller");
		login.setUserName(user.getUsername());
		
		loginServices.addLogin(login);
		System.out.println("Inserted Successfully");
		
		//userService.saveMyUser(user);
		
		Customer customer=new Customer();
		customer.setFirstName(user.getFirstname());
		customer.setLastName(user.getLastname());
		customer.setEmail(user.getEmail());
//		customer.setAddress(user.getAddress());
//		customer.setMobileNo(user.getMobileNo());
		
	//	customerService.saveCustomer(customer);
		
		

		return "redirect:/loginSeller";
	}
	
	

	@GetMapping("/show-users")
	public String showAllUsers(HttpServletRequest request) {
		request.setAttribute("users", userService.showAllUsers());
		request.setAttribute("mode", "ALL_USERS");
		return "welcomepage";
	}

	@RequestMapping("/delete-user")
	public String deleteUser(@RequestParam int id, HttpServletRequest request) {
		userService.deleteMyUser(id);
		request.setAttribute("users", userService.showAllUsers());
		request.setAttribute("mode", "ALL_USERS");
		return "welcomepage";
	}
	
	@RequestMapping("/edit-user")
	public String editUser(@RequestParam int id,HttpServletRequest request) {
		request.setAttribute("user", userService.editUser(id));
		request.setAttribute("mode", "MODE_UPDATE");
		return "welcomepage";
	}
	
	@RequestMapping("/login")
	public String login(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_LOGIN");
		return "welcomepage";
	}
	
	@RequestMapping("/login-admin")
	public String loginAdmin(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_LOGIN_ADMIN");
		return "welcomepage";
	}
	
	@RequestMapping("/login-seller")
	public String loginSeller(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_LOGIN_SELLER");
		return "welcomepage";
	}
	
	@RequestMapping("/dashbord")
	public String dashbord(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_LOGIN");
		return "dashbord";
	}
	
	@RequestMapping ("/login-user")
	public String loginUser(@ModelAttribute User user, HttpServletRequest request) {
		
		String generatedPassword=null;
		
		 try { 
			  
	            // Static getInstance method is called with hashing SHA 
	            MessageDigest md = MessageDigest.getInstance("SHA-256"); 
	  
	            // digest() method called 
	            // to calculate message digest of an input 
	            // and return array of byte 
	            byte[] messageDigest = md.digest(user.getPassword().getBytes()); 
	  
	            // Convert byte array into signum representation 
	            BigInteger no = new BigInteger(1, messageDigest); 
	  
	            // Convert message digest into hex value 
	            generatedPassword = no.toString(16); 
	  
	            while (generatedPassword.length() < 32) { 
	            	generatedPassword = "0" + generatedPassword; 
	            } 
	  
	            
	        } 
	  
	        // For specifying wrong message digest algorithms 
	        catch (NoSuchAlgorithmException e) { 
	            System.out.println("Exception thrown"
	                               + " for incorrect algorithm: " + e); 
	  
	            return null; 
	        } 
		 
		 System.out.println("generated pass : "+generatedPassword);
		
		if(loginServices.findByuserNameAndPassword(user.getUsername(), generatedPassword)!=null){

			
			Login login = loginServices.findByuserNameAndPassword(user.getUsername(), generatedPassword);

			if("Customer".equalsIgnoreCase(login.getRoll())) {
			
			return "redirect:/welcome";
			
			}
			
			else {
				request.setAttribute("error", "Invalid Username or Password");
				request.setAttribute("mode", "MODE_LOGIN");
				return "welcomepage";
			}
			
		}
		else {
			request.setAttribute("error", "Invalid Username or Password");
			request.setAttribute("mode", "MODE_LOGIN");
			return "welcomepage";
			
		}
	}
	
	@RequestMapping ("/loginAdmin")
	public String loginAdmin(@ModelAttribute User user, HttpServletRequest request) {
		
		String generatedPassword=null;
		
		 try { 
			  
	            // Static getInstance method is called with hashing SHA 
	            MessageDigest md = MessageDigest.getInstance("SHA-256"); 
	  
	            // digest() method called 
	            // to calculate message digest of an input 
	            // and return array of byte 
	            byte[] messageDigest = md.digest(user.getPassword().getBytes()); 
	  
	            // Convert byte array into signum representation 
	            BigInteger no = new BigInteger(1, messageDigest); 
	  
	            // Convert message digest into hex value 
	            generatedPassword = no.toString(16); 
	  
	            while (generatedPassword.length() < 32) { 
	            	generatedPassword = "0" + generatedPassword; 
	            } 
	  
	            
	        } 
	  
	        // For specifying wrong message digest algorithms 
	        catch (NoSuchAlgorithmException e) { 
	            System.out.println("Exception thrown"
	                               + " for incorrect algorithm: " + e); 
	  
	            return null; 
	        } 
		
		if(loginServices.findByuserNameAndPassword(user.getUsername(), generatedPassword)!=null) {
		
			
			Login login = loginServices.findByuserNameAndPassword(user.getUsername(), generatedPassword);

			if("admin".equalsIgnoreCase(login.getRoll())) {
			
				return "homepage";
			
			}
			
			else {
				request.setAttribute("error", "Invalid Username or Password");
				request.setAttribute("mode", "MODE_LOGIN");
				return "welcomepage";
			}
			
			
		}
		else {
			request.setAttribute("error", "No User Found");
			request.setAttribute("mode", "MODE_LOGIN");
			return "welcomepage";
			
		}
	}
		
		@RequestMapping ("/loginSeller")
		public String loginSeller(@ModelAttribute User user, HttpServletRequest request,Model model) {
			
			String generatedPassword=null;
			
			System.out.println("username is : "+user.getUsername());
			System.out.println("Password is  : "+user.getPassword());
			
			 try { 
				  
		            // Static getInstance method is called with hashing SHA 
		            MessageDigest md = MessageDigest.getInstance("SHA-256"); 
		  
		            // digest() method called 
		            // to calculate message digest of an input 
		            // and return array of byte 
		            byte[] messageDigest = md.digest(user.getPassword().getBytes()); 
		  
		            // Convert byte array into signum representation 
		            BigInteger no = new BigInteger(1, messageDigest); 
		  
		            // Convert message digest into hex value 
		            generatedPassword = no.toString(16); 
		  
		            while (generatedPassword.length() < 32) { 
		            	generatedPassword = "0" + generatedPassword; 
		            } 
		  
		            
		        } 
		  
		        // For specifying wrong message digest algorithms 
		        catch (NoSuchAlgorithmException e) { 
		            System.out.println("Exception thrown"
		                               + " for incorrect algorithm: " + e); 
		  
		            return null; 
		        } 
			
			 System.out.println("Generated Pass : "+generatedPassword);
			 
			 Login login = loginServices.findByuserNameAndPassword(user.getUsername(), generatedPassword);
			 
			 System.out.println("Login 1 is : "+login.getRoll());
			 
			if(loginServices.findByuserNameAndPassword(user.getUsername(), generatedPassword)!=null) {
			
				
				Login login1 = loginServices.findByuserNameAndPassword(user.getUsername(), generatedPassword);
				
				System.out.println("Role is : "+login1.getRoll());

				if("Seller".equalsIgnoreCase(login1.getRoll())) {
				
					return "redirect:/products";
				
				}
				
				else {
					request.setAttribute("error", "Invalid Username or Password");
					request.setAttribute("mode", "MODE_LOGIN_SELLER");
					return "welcomepage";
				}
				
				
			}
			else {
				request.setAttribute("error", "Invalid Username or Password");
				request.setAttribute("mode", "MODE_LOGIN");
				return "welcomepage";
				
			}
			

		
			
	}
		
		@RequestMapping("/buynow")
		public String buynow(HttpServletRequest request) {

			return "buynow";
		}
		
//		@RequestMapping("/add-cart/{id}")
//		public String editUser1(@PathVariable Integer id,HttpServletRequest request) {
//			System.out.println("Inside"+ id);
//			Product product = productService.getProductById(id);
//			System.out.println("Hey");
//			UserCart userCart = new UserCart();
//			userCart.setId(product.getId());
//			userCart.setUserId(product.getProductId());
//			userCart.setPrice(product.getPrice());
//			cartServices.addToCart(userCart);
//
//			return "redirect:/welcome";
//		}
	
	



}
