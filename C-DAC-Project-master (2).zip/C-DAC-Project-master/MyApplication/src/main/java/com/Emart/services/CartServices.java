package com.Emart.services;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Emart.modal.User;
import com.Emart.modal.UserCart;
import com.Emart.repository.CartRepository;


@Service
@Transactional
public class CartServices {

	@Autowired
	CartRepository cartRepository;
	
	public List<UserCart> showAllItems(){
		List<UserCart> items = new ArrayList<UserCart>();
		for(UserCart user : cartRepository.findAll()) {
			items.add(user);
		}
		
		return items;
	}
	
	public void addToCart(UserCart userCart ) {
		cartRepository.save(userCart);
	}
	
    public void deleteCartProduct(Integer id) {
        cartRepository.delete(id);
    }
}

