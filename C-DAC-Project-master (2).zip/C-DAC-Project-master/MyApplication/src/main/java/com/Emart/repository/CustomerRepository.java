package com.Emart.repository;

import org.springframework.data.repository.CrudRepository;

import com.Emart.modal.Customer;

public interface CustomerRepository extends CrudRepository<Customer, Integer> {

}
