package com.Emart.modal;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "login")
public class Login {

	@Id
	private int id;
	private String userName;
	private String password;
	private String role;
	
	public Login() {
		super();
	}

	public Login(String userName, String password, String roll) {
		super();
		this.userName = userName;
		this.password = password;
		this.role = roll;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRoll() {
		return role;
	}

	public void setRoll(String roll) {
		this.role = roll;
	}

	@Override
	public String toString() {
		return "Login [id=" + id + ", userName=" + userName + ", password=" + password + ", roll=" + role + "]";
	}
	
	
	
	
	
	
}
