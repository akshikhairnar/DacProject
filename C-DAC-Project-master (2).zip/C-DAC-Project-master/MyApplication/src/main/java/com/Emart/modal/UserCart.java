package com.Emart.modal;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "usercart")
public class UserCart {
	
	@Id
	private int id;
	private String userId;
	private BigDecimal price;
	
	public UserCart() {
		super();
	}

	public UserCart(String userId, BigDecimal price) {
		super();
		this.userId = userId;
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "UserCart [id=" + id + ", userId=" + userId + ", price=" + price + "]";
	}
	
	
	
	
	
	

}
